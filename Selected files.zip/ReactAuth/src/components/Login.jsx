import React, { Component } from 'react';
import { Link, Navigate } from 'react-router-dom';
import axios from "axios";

class Login extends Component {

  state={
    email:'',
    password:'',
    message:''
  };

  // Login form submit
  formSubmit = (e) =>{
    e.preventDefault();
    const data={
      email:this.state.email,
      password:this.state.password
    }
    axios.post('/login',data)
    .then((response) => {
      localStorage.setItem('token',response.data.token);
      this.setState({
        loggedIn:true
      })
      this.props.setUser(response.data.user)
    })
    .catch((error) => {
      console.log(error);
    });
  }

  render() {

    // After login redirect to profile
    if(this.state.loggedIn){
      return <Navigate to='/profile' replace={true} />
    }
    
    return (
      <div>
        <br />
        <br />
        <div className="row">
          <div className="jumbotron col-lg-4 offset-lg-4">
            <h3 className="text-center">Login</h3>
            <form onSubmit={this.formSubmit}>
              <div className="form-group">
                <label htmlFor="exampleInputEmail1">Email address</label>
                <input type="email" name="email" className="form-control" required onChange={(e) => {this.setState({"email":e.target.value})}} />
              </div>
              <div className="form-group">
                <label htmlFor="exampleInputPassword1">Password</label>
                <input type="password" name="password" className="form-control" required onChange={(e) => {this.setState({password:e.target.value})}} />
              </div>
              <button type="submit" className="btn btn-primary btn-block">
                Login
              </button>
              <br />
              Forgot Your Password? <Link to="/forget">Click Here</Link>
            </form>
          </div>
        </div>
      </div>
    );
  }
}

export default Login;
