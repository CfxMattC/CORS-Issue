<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ForgetController;
use App\Http\Controllers\ResetController;
use App\Http\Controllers\UserController;

// header('Access-Control-Allow-Origin: *');
// header('Access-Control-Expose-Headers: *');
// header('Access-Control-Allow-Credentials: true');
// header('Access-Control-Allow-Methods: *');
// header('Access-Control-Allow-Headers: *');
// header('Access-Control-Max-Age: 600');

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
//     return $request->user();
// });

// Login Routes
route::post('/login',[AuthController::class, 'Login']);

// Register Routes
route::post('/register',[AuthController::class, 'Register']);

// Forget Password Routes
route::post('/forgetpassword',[ForgetController::class, 'ForgetPassword']);

// Reset Password Routes
route::post('/resetpassword',[ResetController::class, 'ResetPassword']);

// Current User Route
route::get('/user',[UserController::class, 'User'])->middleware('auth:api');